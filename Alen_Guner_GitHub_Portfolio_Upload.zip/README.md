# 🛡️ Alen Guner - Cybersecurity Lab Portfolio

Welcome to my cybersecurity lab portfolio. Each project simulates real-world scenarios and includes documentation, tools used, and outcomes. These labs were designed to showcase my skills as a SOC Analyst and Blue Team cybersecurity professional.

## 📂 Labs Completed

### 1. Brute Force Detection in Wazuh SIEM
🔹 SSH brute force attack using Hydra  
🔹 Wazuh alerting and detection rule writing  
📄 [Download PDF Report](./Alen_Guner_Cybersecurity_Lab_Portfolio_MultiLab.pdf)

### 2. Phishing Email Investigation with Splunk
🔹 Log parsing, VirusTotal enrichment  
🔹 Triage workflow and alert design  
📄 [Download PDF Report](./Alen_Guner_Lab_Phishing_Investigation.pdf)

### 3. Cloud IAM Misconfiguration (AWS)
🔹 Least privilege audit using Cloudsplaining  
🔹 Simulated privilege escalation  
📄 [Download PDF Report](./Alen_Guner_Cybersecurity_Lab_Portfolio_MultiLab.pdf)

### 4. Malware Analysis (Any.Run + Wireshark)
🔹 IOC extraction and PCAP analysis  
🔹 Sandbox execution review  
📄 [Download PDF Report](./Alen_Guner_Lab_Malware_Analysis.pdf)

### 5. SQL Injection Log Detection
🔹 SQLMap attacks on DVWA  
🔹 Zeek and Apache log analysis  
📄 [Download PDF Report](./Alen_Guner_Lab_SQL_Injection_Log_Analysis.pdf)

### 6. Ransomware Simulation + IR Report
🔹 Behavior observation and IR timeline  
🔹 Sysinternals tools and Wireshark  
📄 [Download PDF Report](./Alen_Guner_Lab_Ransomware_IR_Report.pdf)

### 7. Network Segmentation Design
🔹 DMZ, LAN, Management VLAN  
🔹 pfSense firewall rules and isolation  
📄 [Download PDF Report](./Alen_Guner_Lab_Network_Segmentation.pdf)

---

## 📜 About Me

I'm an aspiring cybersecurity analyst with hands-on experience building detection logic, analyzing threats, and designing secure infrastructure. My focus is on practical skills that translate into real-world SOC and incident response capabilities.

🔗 [Connect with me on LinkedIn](https://www.linkedin.com/in/alen-guner)
